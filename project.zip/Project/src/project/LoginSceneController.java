/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;
import javafx.util.Duration;
import org.controlsfx.control.Notifications;

/**
 *
 * @author DELL
 */
public class LoginSceneController implements Initializable {

    @FXML
    private TextField usernameField;
    @FXML
    private Button loginButton;
    @FXML
    private Button registerButton;
    @FXML
    private Label loginMessageLabel;
    @FXML
    private PasswordField passwordField;
    
    private DataInputStream in;
    private DataOutputStream out;  

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void handleLogin(ActionEvent event) {
    String username = usernameField.getText();
    String password = passwordField.getText();

    if (username.isEmpty() || password.isEmpty()) {
        loginMessageLabel.setText("Please enter both username and password.");
        return;
    }
    // Get DataInputStream and DataOutputStream objects from Client class
    DataInputStream in = project.getIn();
    DataOutputStream out = project.getOut();

    // Connect to server
    try {

        // Send login request to server
        out.writeUTF("LOGIN");
        out.writeUTF(username);
        out.writeUTF(password);
        out.flush();

        String response = in.readUTF();

        if (response.equals("LOGIN_SUCCESS")) {
            // Login successful, show main window
         Parent table = FXMLLoader.load(getClass().getResource("Mainpage.fxml"));
       Scene scene =new Scene(table);
    
    // this is to get the stage information 
    
    Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
        window.setScene(scene);
        window.show();
          new NotificationChecker().start();       
        } else {
            loginMessageLabel.setText("Invalid username or password. Please try again.");
        }
    } catch (IOException e) {
    loginMessageLabel.setText("Could not connect to server. Please try again later.");
     Alert alert = new Alert(AlertType.ERROR, "Server is down. Please try again later.");
        alert.showAndWait();
} 
}
    

    @FXML
    public void change(ActionEvent event) throws IOException {
       
    Parent table = FXMLLoader.load(getClass().getResource("Register.fxml"));
    Scene scene =new Scene(table);
    
    // this is to get the stage information 
    
    Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
        window.setScene(scene);
        window.show();
    }
    
    
    public class NotificationChecker extends Thread {
    
    @Override
    public void run() {
       
            
            try {
                Thread.sleep(2000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }


 try {         
           in = project.getIn();
           out = project.getOut();

           out.writeUTF("CHECKNOTIFICATION");
            String response = in.readUTF();

        if (response.equals("success")) {
           int rowCount = in.readInt();
            for (int i = 0; i < rowCount; i++) {
                String name = in.readUTF();
                Image img = new Image("/gift.png");
        ImageView imageView=new ImageView (img);
        imageView.setFitWidth(50);
        imageView.setFitHeight(50);
        Notifications notificationBuilder = Notifications.create()
        .title("You got a Gift")
        .text("your friends contributed on this item " + name)
        .graphic(imageView)
        .hideAfter(Duration.seconds(5))
        .position(Pos.CENTER)     
        .onAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
           
            }
        })   ;
        Platform.runLater(new Runnable() {
                    @Override
                    public void run() {
                     notificationBuilder.show();
                   
                    }
                });
    
               
            }
        }  
          
       
        } catch (IOException ex) {
           ex.printStackTrace();
        }
    
    

        }
    }
    
    
    
    
}
