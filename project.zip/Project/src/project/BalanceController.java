package project;

import static com.sun.org.apache.xalan.internal.xsltc.compiler.util.Type.Text;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.text.Text;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Enter Computer
 */
public class BalanceController  {

    @FXML
    private Button btnCharge;

    @FXML
    private TextField txtBalance;

    @FXML
    private TextField cardField;
    @FXML
    private TextField binField;
    @FXML
    private Text currentBalanceField;

    @FXML
    private Button btnHomeB;

    private DataInputStream in;
    private DataOutputStream out;  
    private String charged ;
    private String  balance ;
    private String currentbalance;
        @FXML
    private Label txtLabel;
    /**
     *
     */
    
           public void initialize () {
               
         try {         
           in = project.getIn();
           out = project.getOut();

           out.writeUTF("CURRENT BALANCE");
            
            currentbalance = in.readUTF();
             System.out.println("current balance is " + currentbalance );
             currentBalanceField.setText(currentbalance);
                
       
        } catch (IOException e) {
        
   Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Server Error");
        alert.setHeaderText(null);
        alert.setContentText("The server is currently down. Please try again later.");
        alert.showAndWait();
        System.exit(0);
    }
              
                 
      
        
            //currentBalanceField.setText(balance);

        // TODO
    }  
    
    
        
 @FXML
        private void Charge (ActionEvent event) throws IOException {
            
            
            
    String card = cardField.getText();
    String pin = binField.getText();
    charged= txtBalance.getText();
    
    if (card.isEmpty() || pin.isEmpty() || charged.isEmpty()) {
        txtLabel.setText("Please enter all of the fields");
        return;
    }
    try {

        out.writeUTF("CHARGE");
        out.writeUTF(card);
        out.writeUTF(pin);
        out.writeUTF(charged);
        

        String response = in.readUTF();

        if (response.equals("CHARGED_SUCCESS")) {
            
                balance = in.readUTF();
              
              currentBalanceField.setText(balance);
              txtLabel.setText("Your Balance have been Charged Successfully. ");
        }  if (response.equals("CHARGED_FAIL")) {
            txtLabel.setText("card number or pin number are not valid. Please try again.");
        }  if (response.equals("NUMBERFORMAT")) {
            txtLabel.setText("enter a valid number to charge");
        } 
    } catch (IOException e) {
    txtLabel.setText("Could not connect to server. Please try again later.");
     Alert alert = new Alert(Alert.AlertType.ERROR, "Server is down. Please try again later.");
        alert.showAndWait();
} 

              
               
              
            
            
}
        
        
  
    
    
 @FXML
        private void HomeB (ActionEvent event) throws IOException {

    Parent table = FXMLLoader.load(getClass().getResource("Mainpage.fxml"));
    Scene scene =new Scene(table);
    
    // this is to get the stage information 
    
    Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
        window.setScene(scene);
        window.show();
}

    
}