/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import static java.lang.System.in;
import static java.lang.System.out;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;
import javafx.util.Duration;
import org.controlsfx.control.Notifications;

/**
 * FXML Controller class
 *
 * @author DELL
 */
public class MainpageController implements Initializable {
    
    private DataInputStream in;
    private DataOutputStream out;  

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
       
    }

 @FXML
     private void gotoWishlist(ActionEvent event) throws IOException {

    Parent table = FXMLLoader.load(getClass().getResource("MyWishList.fxml"));
    Scene scene =new Scene(table);
    
    // this is to get the stage information 
    
    Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
        window.setScene(scene);
        window.show();
}
     
     @FXML
     private void showNotification(ActionEvent event) throws IOException {
         
     try {         
           in = project.getIn();
           out = project.getOut();

           out.writeUTF("CHECKNOTIFICATION");
            String response = in.readUTF();

        if (response.equals("success")) {
           int rowCount = in.readInt();
            for (int i = 0; i < rowCount; i++) {
                String name = in.readUTF();
                Image img = new Image("/gift.png");
        ImageView imageView=new ImageView (img);
        imageView.setFitWidth(50);
        imageView.setFitHeight(50);
        Notifications notificationBuilder = Notifications.create()
        .title("You got a Gift")
        .text("your friends contributed on this item " + name)
        .graphic(imageView)
        .hideAfter(Duration.seconds(5))
        .position(Pos.CENTER)     
        .onAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
           
            }
        })   ;
    notificationBuilder.show();
                
               
            }
        }if (response.equals("notfound")) {
            Image img = new Image("/gift.png");
        ImageView imageView=new ImageView (img);
        imageView.setFitWidth(50);
        imageView.setFitHeight(50);
        Notifications notificationBuilder = Notifications.create()
        .title("notification")
        .text("no notifications until now" )
        .graphic(null)
        .hideAfter(Duration.seconds(5))
        .position(Pos.CENTER)     
        .onAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
           
            }
        })   ;
    notificationBuilder.show();
                
               
            
        }    
          
       
        } catch (IOException ex) {
           ex.printStackTrace();
        }
    
    
    
    
    
}
     @FXML
        private void gotoItems(ActionEvent event) throws IOException {

    Parent table = FXMLLoader.load(getClass().getResource("TrialItems.fxml"));
    Scene scene =new Scene(table);
    
    // this is to get the stage information 
    
    Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
        window.setScene(scene);
        window.show();
}
        
        @FXML
      private void gotoFriends(ActionEvent event) throws IOException {

    Parent table = FXMLLoader.load(getClass().getResource("FriendList.fxml"));
    Scene scene =new Scene(table);
    
    // this is to get the stage information 
    
    Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
        window.setScene(scene);
        window.show();
}
        
    ////Go to request 
        @FXML
        private void logout(ActionEvent event) throws IOException {

    Parent table = FXMLLoader.load(getClass().getResource("LoginScene.fxml"));
    Scene scene =new Scene(table);
    
    // this is to get the stage information 
    
    Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
        window.setScene(scene);
        window.show();
}
        
       @FXML
        private void btnRequests(ActionEvent event) throws IOException {

    Parent table = FXMLLoader.load(getClass().getResource("Request.fxml"));
    Scene scene =new Scene(table);
    
    // this is to get the stage information 
    
    Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
        window.setScene(scene);
        window.show();
}


 @FXML
        private void btnFriendwish(ActionEvent event) throws IOException {

    Parent table = FXMLLoader.load(getClass().getResource("FriendWish.fxml"));
    Scene scene =new Scene(table);
    
    // this is to get the stage information 
    
    Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
        window.setScene(scene);
        window.show();
}
 @FXML
    private void ChargeBalance (ActionEvent event) throws IOException {

    Parent table = FXMLLoader.load(getClass().getResource("Balance.fxml"));
    Scene scene =new Scene(table);
    
    // this is to get the stage information 
    
    Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
        window.setScene(scene);
        window.show();
}


public class NotificationChecker extends Thread {
    
    @Override
    public void run() {
       
            
            try {
                Thread.sleep(2000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }


 try {         
           in = project.getIn();
           out = project.getOut();

           out.writeUTF("CHECKNOTIFICATION");
            String response = in.readUTF();

        if (response.equals("success")) {
           int rowCount = in.readInt();
            for (int i = 0; i < rowCount; i++) {
                String name = in.readUTF();
                Image img = new Image("/gift.png");
        ImageView imageView=new ImageView (img);
        imageView.setFitWidth(50);
        imageView.setFitHeight(50);
        Notifications notificationBuilder = Notifications.create()
        .title("You got a Gift")
        .text("your friends contributed on this item " + name)
        .graphic(imageView)
        .hideAfter(Duration.seconds(5))
        .position(Pos.CENTER)     
        .onAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
           
            }
        })   ;
        Platform.runLater(new Runnable() {
                    @Override
                    public void run() {
                     notificationBuilder.show();
                   
                    }
                });
    
               
            }
        }  
          
       
        } catch (IOException ex) {
           ex.printStackTrace();
        }
    
    

        }
    }
    
  
}
    
    

