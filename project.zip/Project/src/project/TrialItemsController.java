/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Insets;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class TrialItemsController implements Initializable {
    @FXML
    private ScrollPane scrollPane;
    
    @FXML
    private GridPane grid;

    @FXML
    private VBox detailsBox;

    @FXML
    private Label NameLable;
    @FXML
    private Label MessageLabel;

    @FXML
    private Label PriceLabel;

    @FXML
    private ImageView Img;
    
    @FXML
    private Label desc;
    
    @FXML
    private TextField searchField;
    
    private DataInputStream in;
    private DataOutputStream out;
    

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        
        try {
            in = project.getIn();
            out = project.getOut();
            out.writeUTF("WISHITEMS");
            
            List<Product> products = new ArrayList<>();
            grid = new GridPane();
            grid.setPadding(new Insets(5));
            grid.setHgap(20);
            grid.setVgap(20);
            int row = 0;
            int col = 0;
            int rowCount = in.readInt();
            for (int i = 0; i < rowCount; i++) {
            String name = in.readUTF();
            double price = in.readDouble();
            String description = in.readUTF();
            String imageUrl = in.readUTF();
             Image image = new Image("file:///C:/Users/iti/Documents/NetBeansProjects/Project/src/IMG/" + imageUrl);

                ImageView imageView = new ImageView(image);
                imageView.setFitWidth(200);
                imageView.setFitHeight(200);

                // Add image view to grid pane view
                grid.add(imageView, col, row);
                Label nameLabel = new Label(name);
                Label priceLabel = new Label("$" + String.valueOf(price));
                grid.add(nameLabel, col, row + 1);
                grid.add(priceLabel, col, row + 2);
                
                imageView.setOnMouseClicked(event -> {
                   

                    // Create labels for product details
                    NameLable.setText("Product: " + name);
                    PriceLabel.setText("Price: $" + String.valueOf(price));
                    desc.setText("Description: " + description);
                    Img.setImage(image);
                    
                
                });
                col++;
                if (col == 2) {
                    col = 0;
                    row += 3;
                }
                
            }
            scrollPane.setContent(grid);
            scrollPane.setFitToWidth(true);
            scrollPane.setFitToHeight(true);
            
            
        } catch (IOException e) {
        
   Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Server Error");
        alert.setHeaderText(null);
        alert.setContentText("The server is currently down. Please try again later.");
        alert.showAndWait();
        System.exit(0);
    }

    }
    
    
    @FXML
private void handleBackToMain(ActionEvent event) throws IOException {
    
    Parent table = FXMLLoader.load(getClass().getResource("Mainpage.fxml"));
    Scene scene =new Scene(table);
    
    // this is to get the stage information 
    
    Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
        window.setScene(scene);
        window.show();
}


@FXML
private void handleAddItem(ActionEvent event) throws IOException {
    String name = "";
    int price = 0;
    String description = "";

    try {
        // Retrieve product details from labels and image view
        String nameText = NameLable.getText();
        String priceText = PriceLabel.getText();
        String descText = desc.getText();

        // Validate input strings
        if (nameText != null && nameText.length() >= 9) {
            name = nameText.substring(9);
        } else {
            throw new IllegalArgumentException("Invalid name label text");
        }

        if (priceText != null && priceText.length() >= 8) {
            price = (int) Double.parseDouble(priceText.substring(8));
        } else {
            throw new IllegalArgumentException("Invalid price label text");
        }

        if (descText != null && descText.length() >= 13) {
            description = descText.substring(13);
        } else {
            throw new IllegalArgumentException("Invalid description text");
        }

        // Send data to server
        out.writeUTF("ADDTOWISHLIST");
        out.writeUTF(name);
        out.writeInt(price);
        out.writeUTF(description);

        // Receive response from server
        String response = in.readUTF();

        // Update UI based on response
        if (response.equals("ERROR")) {
            MessageLabel.setText("Error adding item");
        } else if (response.equals("ALREADY")) {
            MessageLabel.setText("Item is already added before");
        } else {
            MessageLabel.setText("Item added successfully");
        }
    } catch (IOException ex) {
        Logger.getLogger(TrialItemsController.class.getName()).log(Level.SEVERE, null, ex);
    } catch ( IllegalArgumentException ex) {
        // Handle invalid input
        MessageLabel.setText("choose an item please");
    }
}
 


 @FXML
private void handleSearchButton(ActionEvent event) throws IOException {
    
    try {
            in = project.getIn();
            out = project.getOut();
            out.writeUTF("SEARCHWISHITEMS");
            String search = searchField.getText();
            out.writeUTF(search);
            
            List<Product> products = new ArrayList<>();
            grid = new GridPane();
            grid.setPadding(new Insets(5));
            grid.setHgap(20);
            grid.setVgap(20);
            int row = 0;
            int col = 0;
            int rowCount = in.readInt();
            for (int i = 0; i < rowCount; i++) {
            String name = in.readUTF();
            double price = in.readDouble();
            String description = in.readUTF();
            String imageUrl = in.readUTF();
             Image image = new Image("file:///C:/Users/iti/Documents/NetBeansProjects/Project/src/IMG/" + imageUrl);

                ImageView imageView = new ImageView(image);
                imageView.setFitWidth(200);
                imageView.setFitHeight(200);

                // Add image view to grid pane view
                grid.add(imageView, col, row);
                Label nameLabel = new Label(name);
                Label priceLabel = new Label("$" + String.valueOf(price));
                grid.add(nameLabel, col, row + 1);
                grid.add(priceLabel, col, row + 2);
                
                imageView.setOnMouseClicked(eventtwo -> {
                   

                    // Create labels for product details
                    NameLable.setText("Product: " + name);
                    PriceLabel.setText("Price: $" + String.valueOf(price));
                    desc.setText("Description: " + description);
                    Img.setImage(image);
                    
                
                });
                col++;
                if (col == 2) {
                    col = 0;
                    row += 3;
                }
                
            }
            scrollPane.setContent(grid);
            scrollPane.setFitToWidth(true);
            scrollPane.setFitToHeight(true);
            
            
        } catch (IOException ex) {
            Logger.getLogger(TrialItemsController.class.getName()).log(Level.SEVERE, null, ex);
        }

    }


   private static class Product {
        private int id;
        private String name;
        private int price;
        private String description;
        private String imageUrl;

        public Product(int id, String name, int price, String description, String imageUrl) {
            this.id = id;
            this.name = name;
            this.price = price;
            this.description = description;
            this.imageUrl = imageUrl;
        }

        public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public double getPrice() {
        return price;}
    public String getDescription() {
        return description;
    }

    public String getImageUrl() {
        return imageUrl;
    }
}}

        